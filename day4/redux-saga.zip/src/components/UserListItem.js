import React from 'react';

const UserListItem = ({user, onDeleteClick}) => {

    return (
        <div>
            <div>
                {user.firstName} {user.lastName} 
                <button onClick={() => onDeleteClick(user.id)}>
                    Delete
                </button>
            </div>
        </div>
    );
};

export default UserListItem;