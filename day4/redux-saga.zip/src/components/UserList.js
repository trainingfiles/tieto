import React from 'react';
import UserListItem from './UserListItem';

const UserList = ({users, onDeleteUserClick}) => {
    return (
        <div>
            {users.sort((a, b) => {
                if (a.firstName > b.firstName) {
                    return 1;
                } else if (a.firstName < b.firstName) {
                    return -1;
                } else if (a.lastName > b.lastName) {
                    return 1;
                } else if (a.lastName < b.lastName) {
                    return -1;
                }
                return 0;
            }).map((user) => {
                return (
                    <div key={user.id}>
                        <UserListItem onDeleteClick={onDeleteUserClick} user={user}/>
                    </div>
                );
            })}
        </div>
    );
};

export default UserList;