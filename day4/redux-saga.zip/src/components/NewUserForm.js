import React, {Component} from 'react';

class NewUserForm extends Component {

    state = {
        firstName: '',
        lastName: ''
    };

    handleSubmit = e => {
        e.preventDefault();
        const {firstName, lastName} = this.state;

        this.props.onSubmit({
            firstName,
            lastName
        });

        this.setState({
            firstName: '',
            lastName: ''
        });
    };

    handleFirstNameChange = e => {
        this.setState({
            firstName: e.currentTarget.value
        });
    };

    handleLastNameChange = e => {
        this.setState({
            lastName: e.currentTarget.value
        });
    };

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>
                        First name
                    </label>
                    <input required type="text" value={this.state.firstName} onChange={this.handleFirstNameChange} />
                </div>
                <div>
                    <label>
                        Last name
                    </label>
                    <input required type="text" value={this.state.lastName} onChange={this.handleLastNameChange} />
                </div>
                <div>
                    <button type="submit">
                        Create
                    </button>
                </div>
            </form>
        );
    }
}

export default NewUserForm;