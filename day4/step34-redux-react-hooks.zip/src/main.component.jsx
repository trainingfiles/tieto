import React, { Component } from "react";
import { Provider } from 'react-redux';
import HeroCompWithHooks from "./components/hero-with-hooks.component";
import HeroComp from "./components/hero.component";
import store from "./redux/store";

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>React Redux</h1>
                    <Provider store={ store }>
                        <HeroComp/>
                        <HeroCompWithHooks/>
                    </Provider>
                </div>
    }
}
export default MainApp;