import { connect } from "react-redux";
import { addHero } from "../redux";

let HeroComp = (props)=>{
    return <div>
        <h2>Avengers Enrollment Program</h2>
        <h3>Number of Heroes : {props.numOfHeroes}</h3>
        <button onClick={ props.addHero }>Add Hero</button>
    </div>
}

const mapStateToProps = (state)=>{
    return {
        numOfHeroes : state.numOfHeroes
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        addHero : ()=> dispatch( addHero() )
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(HeroComp);