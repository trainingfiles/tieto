import {  useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux";

let HeroCompWithHooks = ()=>{
    const numOfHeroes = useSelector( state => state.numOfHeroes );
    const dispatch = useDispatch();
    return <div>
        <h2>Avengers Enrollment Program with Hooks</h2>
        <h3>Number of Heroes : {numOfHeroes}</h3>
        <button onClick={ ()=>dispatch( addHero() ) }>Add Hero</button>
    </div>
}

export default HeroCompWithHooks;