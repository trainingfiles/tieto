let BatMovie1Comp = ()=>{
    return <div>
                <h2>Batman Movie 1 Component</h2>
                <h3>Batman Begins</h3>
            </div>
}

export default BatMovie1Comp;