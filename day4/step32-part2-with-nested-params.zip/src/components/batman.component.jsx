import { Outlet } from "react-router-dom";

let BatmanComp = ()=>{
    return <div>
                <h2>Batman Component</h2>
                <Outlet/>
            </div>
}

export default BatmanComp;