let BatMovie2Comp = ()=>{
    return <div>
                <h2>Batman Movie 2 Component</h2>
                <h3>The Dark Knight</h3>
            </div>
}

export default BatMovie2Comp;