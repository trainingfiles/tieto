import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home.component";
import BatmanComp from "./components/batman.component";
import SupermanComp from "./components/superman.component";
import AquamanComp from "./components/aquaman.component";
import FlashComp from "./components/flash.component";
import WonderWomenComp from "./components/wonderwomen.component";
import NotFoundComp from "./components/notfound.component";
import "./routes.style.css";
import BatMovie1Comp from "./components/batmovie1.component";
import BatMovie2Comp from "./components/batmovie2.component";
import BatMovie3Comp from "./components/batmovie3.component";
import { useState } from "react";

let MainApp = ()=>{ 
    let [power, setPower] = useState(0);
    return <div className="container">
                <h2>React Routing power : { power }</h2>
                <button onClick={()=>setPower(power+1)}>Click to increase Power</button>
                <BrowserRouter>
                 {/* <ul>
                     <li><a href="/">Home</a></li>
                     <li><a href="batman">Batman</a></li>
                     <li><a href="superman">Superman</a></li>
                     <li><a href="aquaman">Aquaman</a></li>
                     <li><a href="flash">Flash</a></li>
                     <li><a href="wonderwomen">Wonder Women</a></li>
                     <li><a href="anyotherhero">Others</a></li>
                 </ul> */}
                {/*  <ul className="nav">
                     <li className="boxer nav-item"><Link className="nav-link" to="/">Home</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="batman">Batman</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="superman">Superman</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="aquaman">Aquaman</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="flash">Flash</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="wonderwomen">Wonder Women</Link></li>
                     <li className="boxer nav-item"><Link className="nav-link" to="anyotherhero">Others</Link></li>
                 </ul> */}
                 <ul className="nav">
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="/">Home</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="batman">Batman</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="batman/batmovie1">Batman Movie 1</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="batman/batmovie2">Batman Movie 2</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="batman/batmovie3">Batman Movie 3</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to={ "superman/"+power }>Superman</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="aquaman">Aquaman</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="flash">Flash</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="wonderwomen">Wonder Women</NavLink></li>
                     <li className="nav-item"><NavLink className={({isActive}) => isActive ? 'boxer nav-link' : 'nav-link' } to="anyotherhero">Others</NavLink></li>
                 </ul>
                 <hr />
                    <Routes>
                       {/*  <Route path="/" element={<div> hello from home component </div>}/> */}
                       <Route path="/" element={<HomeComp/>}/> {/* default route */}
                       <Route path="batman" element={<BatmanComp/>}>
                            <Route path="batmovie1" element={<BatMovie1Comp/>}/>
                            <Route path="batmovie2" element={<BatMovie2Comp/>}/>
                            <Route path="batmovie3" element={<BatMovie3Comp/>}/>
                       </Route>
                       <Route path="superman" element={<SupermanComp/>}>
                            <Route path=":pow" element={<SupermanComp/>}/>
                       </Route>
                       <Route path="aquaman" element={<AquamanComp/>}/>
                       <Route path="flash" element={<FlashComp/>}/>
                       <Route path="wonderwomen" element={<WonderWomenComp/>}/> 
                       <Route path="*" element={<NotFoundComp/>}/> {/* wildcard route that captures all unmatched routes */}
                    </Routes>
                </BrowserRouter>
            </div>
}

export default MainApp;