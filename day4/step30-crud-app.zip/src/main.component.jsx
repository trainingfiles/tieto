import { useEffect, useState } from "react";
import axios from "axios";

let MainApp = ()=>{
    let [heroes, setHeroes] = useState([]);
    let [newhero, setNewHero ] = useState({title : '', firstname : '', lastname :'', power : 0, city : ''})
    let [edithero, updateHero ] = useState({title : '', firstname : '', lastname :'', power : 0, city : '', _id:''})
    let [show, manageShow ] = useState(false);
    useEffect(()=> refresh(),[]);
    let errorHandler = (err)=> console.log("Error", err);

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then(dbres => setHeroes(dbres.data))
        .catch(error => errorHandler(error));
    }
    let addNewHero = ()=>{
        axios.post("http://localhost:5050/data", newhero)
        .then(addRes => {
            console.log(addRes.data.message); 
            refresh();
            setNewHero({title : '', firstname : '', lastname :'', power : 0, city : ''})
        })
        .catch(error =>  errorHandler(error));
    }
    let addInputHandler = (evt)=>{
        setNewHero( {...newhero, [evt.target.id] : evt.target.value })
    }
    let editInfoHandler = (evt)=>{
        updateHero( {...edithero, [evt.target.id] : evt.target.value })
    }
    let deleteHandler = (evt)=>{
       // alert(evt.target.getAttribute("data-heroid"))
       axios.delete("http://localhost:5050/delete/"+evt.target.getAttribute("data-heroid"))
       .then( dbres => {
        console.log( dbres.data.message );
        refresh();
       })
       .catch( error =>  errorHandler(error) )
    }
    let editHandler = (evt)=>{
        axios.get("http://localhost:5050/edit/"+evt.target.getAttribute("data-heroid"))
       .then( dbres => {
        // store the hero info to update
         updateHero(dbres.data);
         manageShow(true);
       })
       .catch( error =>  errorHandler(error) )
    }
    let updateHeroInfoHandler = () => {
        axios.post("http://localhost:5050/edit/"+edithero._id, edithero)
        .then( dbres => {
          refresh();
          manageShow(false);
          updateHero({title : '', firstname : '', lastname :'', power : 0, city : '', _id:''})
        })
        .catch( error =>  errorHandler(error) )
    }
    return <div className="container">
                <h2>CRUD Application using Mongo DB</h2>
                { !show && <div>
                    <h3>Add New Hero</h3>
                    <div className="mb-3">
                        <label htmlFor="title" className="form-label">Hero's Title</label>
                        <input onInput={addInputHandler} className="form-control" id="title"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="firstname" className="form-label">First Name</label>
                        <input onInput={addInputHandler} className="form-control" id="firstname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="lastname" className="form-label">Last Name</label>
                        <input onInput={addInputHandler} className="form-control" id="lastname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="power" className="form-label">Hero's Power</label>
                        <input onInput={addInputHandler} type="range" className="form-control" id="power"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="city" className="form-label">Hero's City</label>
                        <input onInput={addInputHandler} className="form-control" id="city"/>
                    </div>
                    <button onClick={addNewHero} className="btn btn-primary">Add New Hero</button>
                </div>}

                { show && <div>
                    <h3>Edit Hero Info</h3>
                    <div className="mb-3">
                        <label htmlFor="title" className="form-label">Hero's Title</label>
                        <input value={edithero.title} onInput={editInfoHandler} className="form-control" id="title"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="firstname" className="form-label">Edit First Name</label>
                        <input value={edithero.firstname} onInput={editInfoHandler} className="form-control" id="firstname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="lastname" className="form-label">Edit Last Name</label>
                        <input value={edithero.lastname} onInput={editInfoHandler} className="form-control" id="lastname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="power" className="form-label">Edit Hero's Power</label>
                        <input value={edithero.power} onInput={editInfoHandler} type="range" className="form-control" id="power"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="city" className="form-label">Edit Hero's City</label>
                        <input value={edithero.city} onInput={editInfoHandler} className="form-control" id="city"/>
                    </div>
                    <button onClick={updateHeroInfoHandler} className="btn btn-primary">Update Hero's Info </button>
                </div>}
                <hr />
                <h3>Heroes List</h3>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Sl #</th>
                            <th>Title</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Power</th>
                            <th>City</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        { heroes.map((hero, idx)=> <tr key={ hero._id }>
                                                        <td>{ idx + 1 }</td>
                                                        <td>{ hero.title }</td>
                                                        <td>{ hero.firstname }</td>
                                                        <td>{ hero.lastname }</td>
                                                        <td>{ hero.power }</td>
                                                        <td>{ hero.city }</td>
                                                        <td>
                                                            <button data-heroid={ hero._id } onClick={ editHandler } className="btn btn-warning">Edit Hero Info</button>
                                                        </td>
                                                        <td>
                                                            <button data-heroid={ hero._id } onClick={ deleteHandler } className="btn btn-danger">Delete Hero</button>
                                                        </td>
                                                    </tr>
                                    )
                        }
                    </tbody>
                </table>
            </div>
}

export default MainApp;