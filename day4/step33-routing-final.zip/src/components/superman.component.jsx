import { useParams } from "react-router-dom";

let SupermanComp = ()=>{
   let params = useParams();
    return <div>
                <h2>Superman Component</h2>
                <h3>Power set by parent is : { params.pow }</h3>
            </div>
}

export default SupermanComp;