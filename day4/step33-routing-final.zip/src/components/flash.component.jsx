let FlashComp = ()=>{
   
    return <div>
                <h2>Flash Component</h2>
            </div>
}

export default FlashComp;