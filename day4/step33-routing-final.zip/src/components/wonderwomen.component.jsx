let WonderWomenComp = ()=>{
   
    return <div>
                <h2>Wonder Women Component</h2>
            </div>
}

export default WonderWomenComp;