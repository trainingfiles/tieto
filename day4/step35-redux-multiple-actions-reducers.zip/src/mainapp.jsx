import { Provider } from "react-redux";
import HeroComp from "./component/hero.component";
import HeroCompHooks from "./component/hero.component-with-hooks";
import MovieComponent from "./component/movie.component";
import MovieCompHooks from "./component/movie.component-with-hooks";
import store from "./redux/store";

let MainApp = ()=>{
    return <div className='container'>
                <h1>Welcome to Heroes Application</h1>
                <hr/>
                <Provider store={ store }>
                    <HeroComp/>
                    <HeroCompHooks/>
                    <hr />
                    <MovieComponent/>
                    <MovieCompHooks/>
                </Provider>
            </div>
}

export default MainApp;
