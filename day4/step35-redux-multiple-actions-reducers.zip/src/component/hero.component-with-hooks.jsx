import { addHero, removeHero } from "../redux"
import { useDispatch, useSelector } from "react-redux";

let HeroCompHooks = ()=>{
    const numOfHeroes = useSelector( state =>  state.heroes.numOfHeroes );
    const dispatch = useDispatch();
    return <div>
                <h2>Avengers Enrollment Program</h2>
                <h3>Number of heroes : { numOfHeroes }</h3>
                <button onClick={ ()=>dispatch( addHero() ) }>Add Hero</button>
                <button onClick={ ()=>dispatch( removeHero() ) }>Remove Hero</button>
            </div>
}


export default HeroCompHooks;