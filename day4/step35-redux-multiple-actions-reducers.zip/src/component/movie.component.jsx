import { addMovie, removeMovie } from "../redux"
import { connect } from "react-redux";

let MovieComp = (props)=>{
    return <div>
                <h2>Manage Avenger's Movies</h2>
                <h3>Number of movies : { props.numOfMovies }</h3>
                <button onClick={ props.addMovie }>Add Movie</button>
                <button onClick={ props.removeMovie }>Remove Movie</button>
            </div>
}

const mapStateToProps = state => {
    return {
        numOfMovies : state.movies.numOfMovies
    }
}
const mapDispatchToProps = dispatch => {
    return {
        addMovie : ()=> dispatch( addMovie() ),
        removeMovie : ()=> dispatch( removeMovie() )
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(MovieComp);