import { addHero, removeHero } from "../redux"
import { connect } from "react-redux";

let HeroComp = (props)=>{
    return <div>
                <h2>Avengers Enrollment Program</h2>
                <h3>Number of heroes : { props.numOfHeroes }</h3>
                <button onClick={ props.addHero }>Add Hero</button>
                <button onClick={ props.removeHero }>Remove Hero</button>
            </div>
}

const mapStateToProps = state => {
    return {
        numOfHeroes : state.heroes.numOfHeroes
    }
}
const mapDispatchToProps = dispatch => {
    return {
        addHero : ()=> dispatch( addHero() ),
        removeHero : ()=> dispatch( removeHero() )
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(HeroComp);