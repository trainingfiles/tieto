import { ADD_MOVIE, REMOVE_MOVIE } from "./movieType"

const moviesIntialState = {
    numOfMovies : 0
}

export const movieReducer = (state = moviesIntialState, action)=>{
    switch(action.type){
        case ADD_MOVIE : return {...state, numOfMovies : state.numOfMovies + 1}
        case REMOVE_MOVIE : return {...state, numOfMovies : state.numOfMovies - 1}
        default : return state
    }
}