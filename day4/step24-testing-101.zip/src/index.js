import { Component } from "react";
import ReactDOM from "react-dom";
import App from "./app";

class MainApp extends Component{

    render(){
        return <div>
                <h1> Welcome Testing 101 </h1>
                <App/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));