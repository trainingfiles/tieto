import { Component } from "react";

class App extends Component{
    state = {
        power : 5
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div>
                <h2>Power is : { this.state.power } </h2>
                <button onClick={ this.increasePower }>Increase the Power</button>
               </div>
    }
}

export default App;