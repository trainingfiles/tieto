import App from './app';
import renderer from 'react-test-renderer';

describe("Testing Component", function(){
    let app = null;

    beforeEach(()=>{
        app = new App();
    });

    test('Should have a power property ', () => {
        expect(app.state.power).toBeDefined();
    })

    test('Should check power to be 5 ', () => {
        expect(app.state.power).toBe(5);
    })

    test('shoule check for power to be less than 10',()=>{
        expect(app.state.power).toBeLessThan(10);
    })

    test("Match the snapshot", function(){
        const domTree = renderer.create(<App/>).toJSON();
        expect(domTree).toMatchSnapshot();
    })
    
})