import { Component } from "react";
import ChildComp from "./child.component";
class AppComp extends Component{
    state = {
        power : 0,
        message : 'default message'
    }
    render(){
        return <div>
                   <h1> Welcome to your life </h1>
                   <h2>Power : { this.state.power }</h2>
                   <h2>Message : { this.state.message }</h2>
                   <ChildComp power={ this.state.power } messageHandler={ this.setMessage }/>
               </div>
    }
    setMessage = (nmessage)=>{
        this.setState({
            message : nmessage
        })
    }
}

export default AppComp;