import React, { Component } from "react";
class ChildComp extends Component{
    inputRef = React.createRef();
    render(){
        return <div>
                   <h2> Hello from Child Component | Power is { this.props.power } </h2>
                   <input ref={ this.inputRef } type="text"/>
                   <button onClick={ ()=> this.props.messageHandler(this.inputRef.current.value)  }>Send Message</button>
               </div>
    }
}

export default ChildComp;