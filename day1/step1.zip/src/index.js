import { createRoot } from "react-dom/client";
import AppComp from "./components/app.component";
// import Element from "./maincomp";

createRoot(document.getElementById("root"))
.render(<AppComp/>)