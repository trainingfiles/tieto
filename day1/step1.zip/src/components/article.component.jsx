import { Component } from "react";

class ArticleComp extends Component{
    render(){
        return <div>
                   <p>
                       Lorem ipsum dolor, sit amet consectetur adipisicing elit. Esse quas praesentium alias doloribus aperiam eum officia est corrupti libero et adipisci dolorum tenetur dolorem maxime iusto repellat beatae, repudiandae recusandae.
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam, numquam unde. Illo magni aut, nesciunt veniam soluta, laboriosam sint ipsa laborum assumenda atque ad voluptates qui? Eius nam fugiat maiores!
                       Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vel provident laboriosam repellat sit nisi quos dolor id doloribus magni, labore quo eligendi aut deleniti illum illo quis, molestias excepturi earum.
                       Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorem architecto laboriosam culpa ad nemo nulla velit accusantium ipsum eum error. Consequuntur optio sequi nisi dolor ratione sint, nesciunt doloribus provident!
                   </p>
               </div>
    }
}

export default ArticleComp;