import { Component } from "react";
import ArticleComp from "./article.component";

class MainComp extends Component{
    render(){
        return <div>
                    <h1>Main Component</h1>
                    <ArticleComp/>
                    <ArticleComp/>
               </div>
    }
}

export default MainComp;