import { Component } from "react";

class FooterComp extends Component{
    render(){
        return <div style={ { backgroundColor : 'yellow' } }>
                   <h3>Copyrights reserved by Tieto &copy;</h3>
               </div>
    }
}

export default FooterComp;