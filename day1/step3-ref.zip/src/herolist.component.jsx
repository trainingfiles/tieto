import { Component } from "react";

class HeroList extends Component{
    render(){
        return <>
            <h2>Title : { this.props.title }</h2>
            <ul>
                { this.props.list.map((val, idx )=> <li key={idx}>{ val }</li> ) }
            </ul>
        </>
    }
}

export default HeroList;