import React, { Component } from "react";
import HeroList from "./herolist.component";
class AppComp extends Component{
    state = {
        avengers : [],
        justiceleague : [],
    }
    avengerIP = React.createRef();
    justiceIP = React.createRef();
    render(){
        return <div>
                   <h1> Welcome to your life </h1>
                   <input ref={ this.avengerIP } type="text" />
                   <button onClick={this.addAvenger.bind(this)}>Add to Avenger</button>
                   <HeroList title="Avengers" list={ this.state.avengers }/>
                   <input ref={ this.justiceIP } type="text" />
                   <button onClick={this.addJusticeLeague.bind(this)}>Add to Jutice League</button>
                   <HeroList title="Justice League" list={ this.state.justiceleague }/>
               </div>
    }
    addAvenger(){
        this.setState({
            avengers : [...this.state.avengers, this.avengerIP.current.value ],
        })
    }
    addJusticeLeague(){
        this.setState({
            justiceleague : [...this.state.justiceleague, this.justiceIP.current.value ],
        })
    }
}

export default AppComp;