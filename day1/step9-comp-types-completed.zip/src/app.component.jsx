import { Component } from "react";
import PureChildComp from "./child-pure.component";
import ChildComp from "./child.component";
import FunMemoComponent from "./fun-memo.component";
import FunComp from "./fun.component";
class AppComp extends Component{
    state = {
        power : 0,
        version : 0
    }
    render(){
        return <div>
                   <h1> Welcome to your life </h1>
                   <button onClick={()=> this.setState({power : this.state.power+1})}>Increase Power</button>
                   <button onClick={()=> this.setState({version : 100})}>Set Version to 100</button>
                   <ChildComp power={ this.state.power } version={ this.state.version }/>
                   <hr />
                   <PureChildComp power={ this.state.power } version={ this.state.version }/>
                   <hr />
                   <FunComp power={ this.state.power } version={ this.state.version }/>
                   <hr />
                   <FunMemoComponent power={ this.state.power } version={ this.state.version }/>
               </div>
    }
}

export default AppComp;