import { PureComponent } from "react";
class PureChildComp extends PureComponent{
    render(){
        console.log("Pure Child Component was rendered", Math.random());
        return <div>
                   <h2> Pure Child Component </h2>
                   <h2> Power is : { this.props.power } </h2>
                   <h2> Version is : { this.props.version } </h2>
               </div>
    }
}

export default PureChildComp;