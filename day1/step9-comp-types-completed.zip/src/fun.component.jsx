let FunComp = (props)=>{
    console.log("Fun Component was rendered", Math.random());
    return <div>
                <h2> Function Child Component </h2>
                <h2> Power is : { props.power } </h2>
                <h2> Version is : { props.version } </h2>
           </div>
}
export default FunComp;