import React from "react";
import { createRoot } from "react-dom/client";
import AppComp from "./app.component";

createRoot(document.getElementById("root"))
.render(<AppComp increasePowerBy={10}/>)

