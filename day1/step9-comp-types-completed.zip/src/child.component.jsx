import { Component } from "react";
class ChildComp extends Component{
    render(){
        console.log("Child Component was rendered", Math.random());
        return <div>
                   <h2> Child Component </h2>
                   <h2> Power is : { this.props.power } </h2>
                   <h2> Version is : { this.props.version } </h2>
               </div>
    }
}

export default ChildComp;