import React from "react";
let FunMemoComp = (props)=>{
    console.log("Fun Memo Component was rendered", Math.random());
    return <div>
                <h2> Function Memo Child Component </h2>
                <h2> Power is : { props.power } </h2>
                <h2> Version is : { props.version } </h2>
           </div>
}
export default React.memo(FunMemoComp);