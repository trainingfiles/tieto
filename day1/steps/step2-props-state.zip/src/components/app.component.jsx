import { Component } from "react";
import FooterComp from "./footer.component";
import HeaderComp from "./header.component";
import MainComp from "./main.component";

class AppComp extends Component{
    render(){
        return <div>
                    <HeaderComp/>
                    <MainComp/>
                    <FooterComp/>
               </div>
    }
}

export default AppComp;