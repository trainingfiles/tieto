import React, { Component } from "react";
import ArticleComp from "./article.component";

class MainComp extends Component{
    para1 = `
    Paragraph 1 content
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aut ipsum aliquam minus veritatis velit voluptate placeat, culpa nostrum quos quas, cum nisi dolores consequuntur voluptates ex sint iure? Voluptates, qui.
    `;
    para2 = `
    Paragraph 2 content
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quis necessitatibus quod, facilis commodi libero repellat iure eos. Ullam suscipit illo eius, praesentium dolores fugit iusto vitae quidem, velit dicta provident.
    `;
    state = {
        version : 1001
    }
    render(){
        return <div>
                <h1>About Tieto</h1>
                <button onClick={ this.clickHandler.bind(this) }>Change Version</button>
                <ArticleComp version={ this.state.version }>{ this.para1 }</ArticleComp>
                <ArticleComp version={ this.state.version }>{ this.para2 }</ArticleComp>
               </div>
    }
    /* clickHandler(){
        this.version = this.version+1;
        console.log(this.version);
        this.forceUpdate();
    } */
    clickHandler(){
       this.setState({
        version : this.state.version + 1
    })
    }
}

export default MainComp;

