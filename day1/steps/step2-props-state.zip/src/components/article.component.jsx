import { Component } from "react";

class ArticleComp extends Component{
    render(){
        return <div>
                    <p>Version : { this.props.version }</p>
                   <p>{ this.props.children }</p>
               </div>
    }
}

export default ArticleComp;