import { Component } from "react";

class HeaderComp extends Component{
    render(){
        return <div style={ { backgroundColor : 'yellow' } }>
                    <h1>Welcome to Tieto India</h1>
               </div>
    }
}

export default HeaderComp;