/* 
let message = 'Welcome to your life';

export let element = <h1>{ message }</h1>; 
*/

// import { Component } from "react";


// class component
/* 
class Element extends Component{
    message = "Welcome to your life !!!"
    render(){
        return <h1>{ this.message }</h1>
    }
}

export default Element;  
*/

// function component
let Element = ()=> {
    let messge = "Welcome to your life, there's no turning back";
    return <h1>{ messge }</h1>
};


export default Element;