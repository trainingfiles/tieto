import { Component } from "react";
import PropTypes from "prop-types";
class ChildComp extends Component{
    /* static defaultProps = {
        childtitle : 'Defaut Child Title',
        childversion : 1000
    } */
    /* static propTypes = {
        childtitle : PropTypes.string.isRequired,
        childversion : PropTypes.number.isRequired
    } */
    render(){
        return <div>
                   <h2> Child Component </h2>
                   {/* <h3>Title : { this.props.childtitle || 'Default Title' }</h3> */}
                   <h3>Title : { this.props.childtitle+"'s message" }</h3>
                   <h3>Version : { this.props.childversion * 10}</h3>
               </div>
    }
}

export default ChildComp;