import { Component } from "react";
import ChildComp from "./child.component";
class AppComp extends Component{
    render(){
        return <div>
                   <h1> Welcome to your life </h1>
                   <hr />
                   <ChildComp childtitle="Child Count 1" childversion={101}></ChildComp>
                   <ChildComp childtitle="Child Count 2" childversion={102}></ChildComp>
                   <ChildComp childtitle="Child Count 3" childversion={103}></ChildComp>
                   <ChildComp childtitle="Child Count 4" childversion={104}></ChildComp>
               </div>
    }
}

export default AppComp;