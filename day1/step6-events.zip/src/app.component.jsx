import React, { Component } from "react";
class AppComp extends Component{
    state = {
        power : 0
    }
    powerRange = React.createRef();
   /*  constructor(){
        super();
        this.increasePower = this.increasePower.bind(this);
    } */
    render(){
        return <div>
                   <h1> Component Power is : { this.state.power } </h1>
                  {/*  <button onClick={ this.increasePower.bind(this) }>Increase Power</button> */}
                   <button onClick={ this.increasePower }>Increase Power</button>
                   <br />
                   <label htmlFor="powerRange">Increase Power To : 
                   <input ref={ this.powerRange } type="range" onInput={ this.increasePowerTo } /> 
                   <br />
                   <input type="range" onInput={ this.increasePowerByEvent } /> 
                   </label>
               </div>
    }
    increasePower = ()=>{
        this.setState({
             power : this.state.power + 1
        }) 
    }
    increasePowerTo = ()=>{
        this.setState({
            power : Number( this.powerRange.current.value )
       }) 
    }

    increasePowerByEvent = (evt)=>{
        this.setState({
            power : parseInt(evt.target.value)
       }) 
    }
       // alert("you clicked the button")
}

export default AppComp;