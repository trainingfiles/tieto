import { Component } from "react";
class AppComp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                   <h1> Power : { this.state.power } </h1>
                   <button onClick={ this.increasePower.bind(this) }>Increase Power</button>
                   <button onClick={ this.decreasePower.bind(this) }>Decrease Power</button>
               </div>
    }
    increasePower(){
        /* this.setState({
            power : this.state.power + 1
        }, function(){
            if(this.state.power === 10){
                console.log("you win");
            }
            console.log("power is ", this.state.power)
        }); */
        this.setState((compState, compProp)=>{
            console.log( compState,compProp ); 
            return {
                power : compState.power + compProp.increasePowerBy
            }
        }, ()=> {
            if(this.state.power === 10){
                console.log("you win");
            }
            console.log("power is ", this.state.power)
        });
    }
    decreasePower(){
        this.setState({
            power : this.state.power + 1
        })
    }
}

export default AppComp;