import { useEffect, useState } from "react";
import axios from "axios";

let ChildComp = () => {
    let [users, setUsers] = useState([]);
    
    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/users").then(res=>setUsers(res.data));
    },[]);

    return <div>
                <h2>List Of Users</h2>
                <ol>
                { users.map(val=><li key={val.id}>{ val.name }</li>)}
                </ol>
            </div>
}
export default ChildComp;