import ChildComp from "./child.component";

let MainApp = ()=>{
  
    return <div>
                <h1>Welcome to your life</h1>
               <ChildComp/>
            </div>
}

export default MainApp;