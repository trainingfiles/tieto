import { Component } from "react";
import axios from 'axios';

class HeroList extends Component{
    state = {
        heroes : []
    }
    componentDidMount(){
        axios.get("http://localhost:5050/data")
        .then(res => this.setState({ heroes : res.data }))
        .catch(error => console.log("Error ", error))
    }
    render(){
        return <div>
                    <h1>Hero List</h1>
                    <ol>{this.state.heroes.map( hero => <li key={hero._id}>{ hero.title }</li>)}</ol>
                </div>
    }
}

export default HeroList;