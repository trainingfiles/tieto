import { Component } from "react";
import HeroList from "./herolist.component";

class MainApp extends Component{
    render(){
        return <div>
                    <h1>Tieto Heroes List</h1>
                    <HeroList/>
                </div>
    }
}

export default MainApp;