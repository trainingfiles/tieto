import { useEffect, useLayoutEffect } from "react";

let ChildComp = (props) => {
    // console.log("Component Rendered")
    /*
    */
    useEffect(function(){
        console.log("ChildComponent was mounted")
    },[]);
/*     useLayoutEffect(function(){
        console.log("ChildComponent's children were set on the layout")
    },[]); */
    useEffect(function(){
        console.log("Power property was changed")
    },[props.power]);
    useEffect(function(){
        return ()=>{
            console.log("ChildComponent was unmounted")
        }
    },[]);

/*     useEffect(function(){
        console.log("ChildComponent was mounted")
        console.log("Power property was changed")
        return ()=>{
            console.log("ChildComponent was unmounted")
        }
    },[props.power]); */

    return <div>
                <h2>Using useEffect Hook</h2>
                <h3>Power : { props.power }</h3>
                <div>{ props.children }</div>
            </div>
}

export default ChildComp;