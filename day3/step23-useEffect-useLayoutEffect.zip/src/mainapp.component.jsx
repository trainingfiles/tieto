import { useEffect, useState } from "react";
import ChildComp from "./child.component";

let MainApp = ()=>{
    let [power, setPower] = useState(0);
    let [show, toggleShow] = useState(true);
   /*  useEffect(function(){
        console.log("MainApp was mounted")
    }); */
    return <div>
                <h1>Welcome to your life</h1>
                <button onClick={ ()=> setPower(power+1)}>Change Power</button>
                <button onClick={ ()=> toggleShow(!show)}>Show / Hide Child Component</button>
                { show ? <ChildComp power={power}>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nam aliquid reprehenderit, provident quos numquam rerum! Rerum, est velit libero, quidem nesciunt laudantium vero, fugiat adipisci amet ducimus illum? Vero, aliquam.
                    </p>
                </ChildComp> : "Child Component is hidden"}
            </div>
}

export default MainApp;