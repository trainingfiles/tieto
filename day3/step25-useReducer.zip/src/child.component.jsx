import { useReducer } from "react";

let ChildComp = () => {
    let reducerFun = (state, action)=>{
        switch(action.type){
            case "INCREASEPOWER" : return{ ...state, power : state.power + 1 }
            case "DECREASEPOWER" : return{ ...state, power : state.power - 1 }
            default : return state
        }
    };
    let [ store, dispatch ] = useReducer(reducerFun, { power : 0 });
    return <div>
                <h2>Power / Version / Stock</h2>
                <label htmlFor="power">Increase / Decrease Power { store.power }</label>
                <br />
                <button onClick={ ()=> dispatch({ type : "INCREASEPOWER"})}> Increase Power </button>
                <button onClick={ ()=> dispatch({ type : "DECREASEPOWER"})}> Decrease Power </button>
               
            </div>
}
export default ChildComp;