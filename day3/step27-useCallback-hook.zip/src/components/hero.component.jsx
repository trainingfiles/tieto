import { useCallback, useState } from 'react';
import Button from './button.component';
import Log from './log.component';
import Title from './title.component';
let HeroComp = ()=>{
    let [power, setPower] = useState(1);
    let [version, setVersion] = useState(1);
// in react functions are created once every re-render of the component
// useCallback hook will keep the callback in memory and changes the callback only when the dependencies are changed.
    let increasePower = useCallback( ()=>{ setPower(power + 1) }, [power]);
    let increaseVersion = useCallback( ()=>{ setVersion(version + 1) }, [version]);

    return <div>
                <Title/>
                <Log text="Power" message={ power }></Log>
                <Button clickHandler={ increasePower }>Increase Power</Button>
                <hr />
                <Log text="Version" message={ version }></Log>
                <Button clickHandler={ increaseVersion }>Increase Version</Button>
            </div>
}

export default HeroComp;