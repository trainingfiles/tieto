import React from 'react';

let Log = ({text, message})=>{
    console.log("Log was rendered for ",text)
    return <p>{text+" ~ "+message}</p>
}

export default React.memo(Log)