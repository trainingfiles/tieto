import React from 'react';

let Title = ()=>{
    console.log("Title was rendered")
    return <h1>Using Callback Hook</h1>
}

export default React.memo(Title);