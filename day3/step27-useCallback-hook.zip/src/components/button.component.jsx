import React from 'react';

let Button = ({clickHandler, children})=>{
    console.log("Button was rendered ",children);
    return <button onClick={ clickHandler }>{ children }</button>
}
export default React.memo(Button)