import HeroComp from "./components/hero.component";

let MainApp = ()=>{
    return <div className="container">
                    <h1>Main Application</h1>
                    <HeroComp/>
                </div>
}

export default MainApp;
