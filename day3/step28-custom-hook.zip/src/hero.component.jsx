let HeroComp = ()=>{
    return <div>
                <h1>Hero Component</h1>
            </div>
}

export default HeroComp;