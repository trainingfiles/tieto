// import { useState } from "react";
import HeroComp from "./hero.component";
import useShowHide from "./useShowHide";

let MainApp = ()=>{
    // let [show, setShowHide] = useState(true);
    // console.log(useShowHide("hello Tieto"));
    let [show, setShowHide] = useShowHide(true)
    return <div className="container">
                <h1>Main Application</h1>
                <input type="checkbox" 
                onChange={ ()=> setShowHide() } />
    { show ? <HeroComp/> : "Hero Component is hidden" }
            </div>
}

export default MainApp;
