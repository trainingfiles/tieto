import { useState } from "react";

let useShowHide = (initVal)=>{
    let [state, setState] = useState(initVal);
    let toggle = ()=>{
        setState(!state);
    }
    return [state, toggle]
};

export default useShowHide;