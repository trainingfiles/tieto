/* import React, { useState } from "react"

let HeroList = ()=>{
    let [heroes, setHeroes] = useState([]);
    let ipRef = React.createRef();
    return <div>
                <input ref={ipRef} type="text" />
                <button onClick={()=> setHeroes([...heroes, ipRef.current.value])}>Add Hero</button>
                <ol>
                    {heroes.map((val,idx)=><li key={idx}>{ val }</li>)}
                </ol>
            </div>
}

export default HeroList; */


import React, { useRef, useState } from "react"

let HeroList = ()=>{
    let [heroes, setHeroes] = useState([]);
    let idRef = useRef();
    let nameRef = useRef();
    return <div>
                <input ref={idRef} type="number" defaultValue={heroes.length+1} />
                <input ref={nameRef} type="text" />
                <button onClick={()=> setHeroes([...heroes, { id : idRef.current.value, title : nameRef.current.value }])}>Add Hero</button>
                <ol>
                    {heroes.map((val)=><li key={val.id}>{ JSON.stringify(val) }</li>)}
                </ol>
            </div>
}

export default HeroList;