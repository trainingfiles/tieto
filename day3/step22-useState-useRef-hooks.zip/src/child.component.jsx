/* import { Component } from "react";

class ChildComp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    render(){
        return <div>
                    <h2>Using useState Hook</h2>
                    <hr />
                    <h3>Power : { this.state.power }</h3>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                </div>
    }
}

export default ChildComp; 
*/

import { useState } from "react";
let ChildComp = ()=>{
    // console.log( useState() )
    /*     
    let heroes = ['batman', 'superman'];
    function getHeroes(){
        return heroes;
    }
    let [firsthero, secondhero] = getHeroes(); 
    */

    let [ power, setPower ] = useState(0);

    let [ userinfo, setUserInfo ] = useState({ firstname : 'default first name', lastname : 'default last name' })
    
    return <div>
                <h2>Using useState Hook</h2>
                <hr/>
                <h3>Power : { power } </h3>
                <button onClick={()=>setPower(power+1)} >Increase Power</button>
                <button onClick={()=>setPower(power-1)} >Decrease Power</button>
                <hr />
                <ul>
                    <li>First Name { userinfo.firstname }</li>
                    <li>Last Name { userinfo.lastname }</li>
                </ul>
                <label htmlFor="firstname">First Name : </label>
                <input id="firstname" type="text" onInput={(evt)=>setUserInfo({ ...userinfo, firstname : evt.target.value })} />
                <br />
                <label htmlFor="lastname">Last Name : </label>
                <input id="lastname" type="text" onInput={(evt)=>setUserInfo( { ...userinfo, lastname :evt.target.value })} />
                <br />
                <button onClick={()=> setUserInfo({ firstname : 'Bruce', lastname : 'Wayne'}) }>Change User Info</button>
            </div>
}

export default ChildComp;