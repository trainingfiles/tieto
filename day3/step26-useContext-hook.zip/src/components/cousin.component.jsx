import { useContext } from "react";
import { FamilyContext } from "../contexts/family.context";

let CousinComp = ()=>{
    let val = useContext(FamilyContext);
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1> Cousin Component</h1>
                    {/* <FamilyContext.Consumer>{(val)=> <h2>{ val || 'place holder' }</h2> }</FamilyContext.Consumer> */}
                    <h2>{ val || 'place holder' }</h2>
               </div>
}

export default CousinComp;
