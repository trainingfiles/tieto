import { useContext } from "react";
import { FamilyContext } from "../contexts/family.context";

let ChildComp = ()=> {
    let val = useContext(FamilyContext);
    return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1> Child Component</h1>
                    {/* <FamilyContext.Consumer>{(val)=> <h2>{ val || 'place holder' }</h2> }</FamilyContext.Consumer> */}
                    <h2>{ val || 'place holder' }</h2>  
                    <hr />
                    <h2>{ val || 'place holder' }</h2>  
                    <hr />
                    <h2>{ val || 'place holder' }</h2>  
             </div>
}

export default ChildComp;
