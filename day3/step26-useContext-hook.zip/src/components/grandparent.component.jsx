import  {  useRef, useState } from "react";
import { FamilyContext } from "../contexts/family.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parent.component";

let GrandParentComp = ()=> {
    let [message, setMessage] = useState('')
    let inputRef = useRef();
    let clickHandler = ()=>{
        setMessage(inputRef.current.value)
    }
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1>Grand Parent Component</h1>
                     Message : { message }
                    <input ref={ inputRef} className="mb-2 form-control" type="text" />
                    <button onClick={  clickHandler } className="btn btn-primary">Send Message</button>
                    <FamilyContext.Provider value={message}>
                        <ParentComp />
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
}

export default GrandParentComp;
