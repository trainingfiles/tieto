import GrandParentComp from "./components/grandparent.component";

let MainApp = ()=>{
    return <div className="container">
                    <h1>Main Application</h1>
                    <GrandParentComp/>
                </div>
}

export default MainApp;
