import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1> Child Component</h1>
                    <h2>{ "place holder" }</h2>
               </div>
    }
}

export default ChildComp;
