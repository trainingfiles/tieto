import { Component } from "react";
import { compStyle } from "./ext-inline-style";

import tietoclient from  "./client.module.css";
import "./external.css";

class MainApp extends Component{

    render(){
        return <div>
                    <p style={ compStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi laudantium ut vero unde asperiores officiis, quisquam eligendi velit at ad facere consectetur enim sunt, distinctio nulla nemo repellendus? Voluptate, sint?
                    </p>
                    <p  style={ {...compStyle, backgroundColor : "crimson"} }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi laudantium ut vero unde asperiores officiis, quisquam eligendi velit at ad facere consectetur enim sunt, distinctio nulla nemo repellendus? Voluptate, sint?
                    </p>
                    <p  style={ compStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi laudantium ut vero unde asperiores officiis, quisquam eligendi velit at ad facere consectetur enim sunt, distinctio nulla nemo repellendus? Voluptate, sint?
                    </p>
                    <p className="box">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi laudantium ut vero unde asperiores officiis, quisquam eligendi velit at ad facere consectetur enim sunt, distinctio nulla nemo repellendus? Voluptate, sint?
                    </p>
                    <p className={tietoclient.box}>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi laudantium ut vero unde asperiores officiis, quisquam eligendi velit at ad facere consectetur enim sunt, distinctio nulla nemo repellendus? Voluptate, sint?
                    </p>
               </div>        
    }
   
}

export default MainApp;