export let compStyle =  { 
    backgroundColor: "cyan", 
    fontFamily: "arial", 
    padding : "10px", 
    margin : "10px" 
};