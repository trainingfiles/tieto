import { Component } from "react";

class MainApp extends Component{
    state = {
        power : 0,
        show : false
    }
    render(){
        /* if(this.state.show){
            return <div>
            <h1>Main Application</h1>
            <button onClick={ this.increasePower }>Increase Power</button>
            <button onClick={ this.toggleShowHide }>Show Terms & Conditions</button>
            <hr />
            <fieldset>
                <legend>Terms & Conditions</legend>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi earum inventore necessitatibus impedit? Tenetur est facere quibusdam odio dolore cupiditate dolorem consequuntur vero? Maxime excepturi exercitationem suscipit? Reprehenderit, quia exercitationem!
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus ab debitis delectus deserunt sunt iusto explicabo cumque nemo officia voluptatem nihil incidunt, repellendus possimus eveniet sit consectetur voluptates alias fugiat!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, velit nihil libero eaque nemo assumenda, magnam doloribus molestias mollitia vitae, ipsam odio aliquid! Delectus vero neque ab optio eligendi aliquam.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vero expedita quisquam debitis optio ipsa autem! Tempore, perspiciatis omnis obcaecati corporis, ipsa maiores quo quis deserunt quam, facilis illum nam eligendi.
                </p>
            </fieldset>
        </div>
        }else{
            return <div>
                    <h1>Main Application</h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.toggleShowHide }>Show Terms & Conditions</button>
                    <hr />
                </div>
        } */

            return <div>
            <h1>Main Application</h1>
            <button onClick={ this.increasePower }>Increase Power</button>
            <hr />
           {/*  { this.state.show ? <fieldset>
                <legend>Terms & Conditions</legend>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi earum inventore necessitatibus impedit? Tenetur est facere quibusdam odio dolore cupiditate dolorem consequuntur vero? Maxime excepturi exercitationem suscipit? Reprehenderit, quia exercitationem!
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus ab debitis delectus deserunt sunt iusto explicabo cumque nemo officia voluptatem nihil incidunt, repellendus possimus eveniet sit consectetur voluptates alias fugiat!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, velit nihil libero eaque nemo assumenda, magnam doloribus molestias mollitia vitae, ipsam odio aliquid! Delectus vero neque ab optio eligendi aliquam.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vero expedita quisquam debitis optio ipsa autem! Tempore, perspiciatis omnis obcaecati corporis, ipsa maiores quo quis deserunt quam, facilis illum nam eligendi.
                </p>
                <button onClick={ this.toggleShowHide }>Hide Terms and Conditions</button>
            </fieldset> :  <button onClick={ this.toggleShowHide }>Show Terms & Conditions</button> } */}
            <button onClick={ this.toggleShowHide }>Show / Hide Terms and Conditions</button>
            { this.state.show && <fieldset>
                <legend>Terms & Conditions</legend>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi earum inventore necessitatibus impedit? Tenetur est facere quibusdam odio dolore cupiditate dolorem consequuntur vero? Maxime excepturi exercitationem suscipit? Reprehenderit, quia exercitationem!
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus ab debitis delectus deserunt sunt iusto explicabo cumque nemo officia voluptatem nihil incidunt, repellendus possimus eveniet sit consectetur voluptates alias fugiat!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo, velit nihil libero eaque nemo assumenda, magnam doloribus molestias mollitia vitae, ipsam odio aliquid! Delectus vero neque ab optio eligendi aliquam.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vero expedita quisquam debitis optio ipsa autem! Tempore, perspiciatis omnis obcaecati corporis, ipsa maiores quo quis deserunt quam, facilis illum nam eligendi.
                </p>
            </fieldset> }
        </div>
        
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    toggleShowHide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
}

export default MainApp;