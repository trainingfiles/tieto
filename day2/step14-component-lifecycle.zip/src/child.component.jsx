import { Component } from "react";

class ChildComp extends Component{
    state = {
        power : 0
    }
    log = [];
    constructor(){
        super();
        this.state = { power : 10 };
        console.log("ChildComp's constructor was called")
    }
    static getDerivedStateFromProps(compProp, compState){
        console.log("ChildComp's getDerivedStateFromProps was called");
        // console.log(compProp, compState);
        return {
            power : compProp.pow
        }
    }
    shouldComponentUpdate(...args){
        console.log("ChildComp's shouldComponentUpdate was called")
        // console.log(args[0], args[1])
        if(args[0].pow > 5){
            return false
        }else{
            return true
        }
    }
    componentDidMount(){
        // this is the first thing a component will call after mounting on to the parent
        // useful to subscribe api calls
        console.log("ChildComp's componentDidMount was called")
    }
    getSnapshotBeforeUpdate(compProps, compState){
        console.log(compProps, compState);
        console.log("ChildComp's getSnapshotBeforeUpdate was called")
        return {
            compProps : compProps,
            compState : compState,
            time : new Date()
        }
    }
    componentDidUpdate(compProps, compState, snapshot){
        // console.log(args.length);// 3
        console.log("ChildComp's componentDidUpdate was called")
        this.log.push(snapshot);
        console.log(this.log.length, this.log)
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called");
        // useful to unsubscribe from api calls
    }
    render(){
        console.log("ChildComp's render was called")
        let props = this.props;
        return <div>
                    <h1>Child Component</h1>
                    <h2>State Power is { this.state.power }</h2>
                    <h2>Prop Power is { props.pow }</h2>
               </div>
    }
}

export default ChildComp;