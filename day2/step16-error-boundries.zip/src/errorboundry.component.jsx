import { Component } from "react";

class ErrorBoundry extends Component{
    state = {
        hasError : false,
        errorMessage : ''
    }
    /* static getDerivedStateFromError(error){
        return  {
            hasError : true,
            errorMessage : error.message
        }
    } */
    componentDidCatch(error, errorComp){
        this.setState({
            hasError : true,
            errorMessage : error.message
        })
    }
    render(){
        if(this.state.hasError){
            return <h3>Hero is not rendered because : { this.state.errorMessage }</h3>
        }else{
            return this.props.children
        }
    }
}


export default ErrorBoundry;