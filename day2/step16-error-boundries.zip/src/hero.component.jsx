import { Component } from "react";

class HeroComp extends Component{
    render(){
       if( this.props.power < 5){
            throw new Error("Hero is not ready to fight");
       }else{
        return <div>
                   <h2>Hero Component | Power { this.props.power }</h2>
               </div>
       }
    }
}

export default HeroComp;
