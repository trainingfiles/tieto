import { Component } from "react";
import ErrorBoundry from "./errorboundry.component";
import HeroComp from "./hero.component";

class MainApp extends Component{
    render(){
        return <div>
            <h1>Main Application</h1>
            <hr />
            <ErrorBoundry>
                <HeroComp power={5}/>
            </ErrorBoundry>
            <ErrorBoundry>
                <HeroComp power={4}/>
            </ErrorBoundry>
            <ErrorBoundry>
                <HeroComp power={7}/>
            </ErrorBoundry>
            <ErrorBoundry>
                <HeroComp power={8}/>
            </ErrorBoundry>
            <ErrorBoundry>
                <HeroComp power={3}/>
            </ErrorBoundry>
            <ErrorBoundry>
                <HeroComp power={6}/>
            </ErrorBoundry>
        </div>
    }
}

export default MainApp;
