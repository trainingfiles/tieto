import { Component } from "react";
import PopUp from "./popup.component";

class MainApp extends Component{
    state = {
        show : true
    }
    render(){
        return <div>
                    <h1>Main Application</h1>
                    { this.state.show ? <PopUp>
                            <div>
                                <h1>PopUp Component</h1>
                                <hr />
                                <p>
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum quae maxime quidem. Officia, minima qui totam doloribus consectetur provident distinctio? Nisi obcaecati atque officiis ducimus eveniet id? Exercitationem, nulla quam?
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias fugiat deserunt quidem aut hic dolore aperiam consectetur sequi error rerum quae placeat, officia quaerat eius ullam odio consequuntur officiis debitis.
                                </p>
                            </div>
                              <button onClick={ this.showHide }>Hide Popup</button>
                    </PopUp>: <button onClick={ this.showHide }>Show Popup</button> }
               </div>
    }
    showHide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
}

export default MainApp;