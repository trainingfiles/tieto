import React, { Component } from "react";
import { FamilyContext } from "../contexts/family.context";
import { GeneralContext } from "../contexts/general.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parent.component";

class GrandParentComp extends Component{
    state = {
        message : '',
        version : 0
    }
    inputRef = React.createRef();
    setMessage = ()=>{
        this.setState({
            message : this.inputRef.current.value,
        })
    }
    setVersion = ()=>{
        this.setState({
            version : Math.round( Math.random() * 1000 )
        })
    }
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1>Grand Parent Component</h1>
                     Message : { this.state.message }
                    <input ref={this.inputRef} className="mb-2 form-control" type="text" />
                    <button onClick={ this.setMessage } className="btn btn-primary">Send Message</button>
                    <button onClick={ this.setVersion } className="btn btn-primary">Send Version</button>
                    <FamilyContext.Provider value={this.state.message}>
                        <GeneralContext.Provider value={this.state.version}>
                            <ParentComp />
                            <CousinComp />
                        </GeneralContext.Provider>
                    </FamilyContext.Provider>

                </div>
    }
}

export default GrandParentComp;
