import { Component } from "react";
import { FamilyContext } from "../contexts/family.context";
import { GeneralContext } from "../contexts/general.context";

class CousinComp extends Component{
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1> Cousin Component</h1>
                    <FamilyContext.Consumer>{(val)=> <h2>{ val || 'place holder' }</h2> }</FamilyContext.Consumer>
                    <GeneralContext.Consumer>{ ver => <h2>Version : { ver }</h2>}</GeneralContext.Consumer>
               </div>
    }
}

export default CousinComp;
