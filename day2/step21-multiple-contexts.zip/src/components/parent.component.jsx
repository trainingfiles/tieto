import { Component } from "react";
import { GeneralContext } from "../contexts/general.context";
import ChildComp from "./child.component";

class ParentComp extends Component{
    render(){
        return <div  style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
            <h1> Parent Component</h1>
            <GeneralContext.Consumer>{ ver => <h2>Version : { ver }</h2>}</GeneralContext.Consumer>
            <ChildComp/>
        </div>
    }
}

export default ParentComp;
