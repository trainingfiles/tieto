import React from 'react';
export let GeneralContext = React.createContext()