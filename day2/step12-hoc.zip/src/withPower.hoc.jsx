import { Component } from "react"

let WithPower = (OriginalComponent)=>{
    class TempComp extends Component{
        state = {
            power : 0
        }
        render(){
            // return <OriginalComponent version={ this.props.version } title={ this.props.title } incPow={ this.increasePower } power={ this.state.power } />
            return <OriginalComponent  { ...this.props }  incPow={ this.increasePower } power={ this.state.power } />
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
    }
    return TempComp
}

export default WithPower;