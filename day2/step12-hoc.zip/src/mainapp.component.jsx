
import { Component } from "react";
import PowerClickComp from "./powerclick.component";
import PowerSlideComp from "./powerslide.component";

class MainApp extends Component{
   
    render(){
        return <div>
                    <PowerClickComp version="101" title="Power Click Component"/>
                    <PowerSlideComp version="201" title="Power Slide Component"/>
                </div>
    }
  
}

export default MainApp;