import { Component } from "react";
import WithPower from "./withPower.hoc";

class PowerClickComp extends Component{
    render(){
        return <div>
                    <h1>Power Click Component | { this.props.title } version : { this.props.version }</h1>
                    <h2>Power is : { this.props.power }</h2>
                    <button onClick={ this.props.incPow }>Increase Power</button>
                </div>
    }
   
}

export default WithPower(PowerClickComp);