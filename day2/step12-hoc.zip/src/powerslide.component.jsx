import { Component } from "react";
import WithPower from "./withPower.hoc";

class PowerSlideComp extends Component{
    render(){
        return <div>
                    <h1>Power Slide Component  | { this.props.title }  version : { this.props.version }</h1>
                    <h2>Power is : { this.props.power }</h2>
                    <div style={ { backgroundColor : "crimson", width : "150px", height : "50px", color : 'papayawhip', textAlign: "center", lineHeight:"50px" } } onMouseMove={ this.props.incPow }>Increase Power</div>
                </div>
    }
}

export default WithPower(PowerSlideComp);