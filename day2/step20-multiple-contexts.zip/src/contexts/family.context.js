import React from 'react';

let FamilyContext = React.createContext();

/* 
let FamilyContextProvider = FamilyContext.Provider;
let FamilyContextConsumer = FamilyContext.Consumer;

export { FamilyContextProvider, FamilyContextConsumer }
*/

export { FamilyContext }