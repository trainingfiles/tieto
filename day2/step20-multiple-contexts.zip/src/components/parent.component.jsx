import { Component } from "react";
import { ParentContext } from "../contexts/parent.context";
import ChildComp from "./child.component";

class ParentComp extends Component{
    render(){
        return <div  style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
            <h1> Parent Component</h1>
            <ParentContext.Provider value={'family name'}>
                <ChildComp/>
            </ParentContext.Provider>
        </div>
    }
}

export default ParentComp;
