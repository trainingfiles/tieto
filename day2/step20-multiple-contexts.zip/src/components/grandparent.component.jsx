import React, { Component } from "react";
import { FamilyContext } from "../contexts/family.context";
import CousinComp from "./cousin.component";
import ParentComp from "./parent.component";

class GrandParentComp extends Component{
    state = {
        message : ''
    }
    inputRef = React.createRef();
    setMessage = ()=>{
        this.setState({
            message : this.inputRef.current.value
        })
    }
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1>Grand Parent Component</h1>
                     Message : { this.state.message }
                    <input ref={this.inputRef} className="mb-2 form-control" type="text" />
                    <button onClick={ this.setMessage } className="btn btn-primary">Send Message</button>
                    <FamilyContext.Provider value={this.state.message}>
                        <ParentComp />
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
    }
}

export default GrandParentComp;
