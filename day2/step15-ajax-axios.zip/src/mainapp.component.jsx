import { Component } from "react";
import axios from "axios";

class MainApp extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((res)=> this.setState({ users : res.data }) )
        .catch((error)=> console.log("Error", error))
    }
    render(){
        return <div>
                    <h1>Main Application</h1>
                    <hr />
                    <ul>
                        {this.state.users.map( val => <li key={ val.id }>{ val.name }</li>)}
                    </ul>
               </div>
    }
}

export default MainApp;