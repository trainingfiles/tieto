import { Component } from "react";
import FormsComponent from "./forms.component";

class MainApp extends Component{
    render(){
        return <div className="container">
                <h1>Forms API</h1>
                <hr />
                <FormsComponent/>
               </div>
    }
}

export default MainApp;
