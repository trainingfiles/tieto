import { Component } from "react";

class FormsComponent extends Component{
  state = {
    username : '',
    usercity : '',
    userage : 0,
    usernameError : false,
    usercityError : false,
    userageError : false,
    below18Error : false,
    above90Error : false
  }
  usernameChangeHandler = (evt)=>{
    this.setState({
      username : evt.target.value
    })
  }
  usercityChangeHandler = (evt)=>{
    this.setState({
      usercity : evt.target.value
    })
  }
  userageChangeHandler = (evt)=>{
    this.setState({
      userage : Number( evt.target.value )
    }) 
  }

  /* submitHandler = (evt)=>{
    evt.preventDefault();
    if(this.state.username === ''){
      this.setState({  usernameError : true })
    }else if(this.state.usercity === ''){
      this.setState({  usercityError : true })
    }else if(this.state.userage === 0){
      this.setState({  userageError : true })
    }else if(this.state.userage < 18){
      this.setState({  below18Error : true })
    }else if( this.state.userage > 90){
      this.setState({  above90Error : true })
    }else{
      evt.target.submit();
      this.setState({ 
        usernameError : false,
        usercityError : false,
        userageError : false,
        below18Error : false,
        above90Error : false
      })
    }*/

    submitHandler = (evt)=>{
      evt.preventDefault();
      if(this.state.username === ''){
        this.setState({  usernameError : true })
      } else if(this.state.usercity === ''){
        this.setState({  usercityError : true, usernameError : false })
      } else   
      if(this.state.userage === 0){
        this.setState({  userageError : true, usercityError : false, usernameError : false })
      }else if(this.state.userage < 18){
        this.setState({ below18Error : true,  userageError : false, above90Error : false, usernameError : false, usercityError : false  })
      }else if( this.state.userage > 90){
        this.setState({  above90Error : true, userageError : false, below18Error : false, usernameError : false, usercityError : false })
      }else{
        evt.target.submit();
        this.setState({ 
          usernameError : false,
          usercityError : false,
          userageError : false,
          below18Error : false,
          above90Error : false
        })
      }
  } 
  /* 
  changeHandler = (evt)=>{
    this.setState({
      [evt.target.id] : evt.target.value
    }) 
  }
 */
  render(){
    return <div>
        <h2>User Registeration Form</h2>
            <form action="#" method="get" onSubmit={ this.submitHandler }>
            <div className="mb-3">
              <label htmlFor="username" className="form-label">Your Name</label>
              <input name="username" onChange={ this.usernameChangeHandler } value={this.state.username} id="username" type="text" className="form-control"/>
              { this.state.usernameError && <div className="form-text text-danger">Enter your Name</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="usercity" className="form-label">Your City</label>
              <input name="usercity" onChange={ this.usercityChangeHandler } value={this.state.usercity} id="usercity" type="text" className="form-control"/>
              { this.state.usercityError && <div className="form-text text-danger">Enter your City</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="userage" className="form-label">Your Age</label>
              <input name="userage" onChange={ this.userageChangeHandler } value={this.state.userage} id="userage" type="number" className="form-control"/>
              { this.state.userageError && <div className="form-text text-danger">Enter your Age</div>}
              { this.state.below18Error && <div className="form-text text-danger">You are too young to join us</div>}
              { this.state.above90Error && <div className="form-text text-danger">You are too old to join us</div> }
            </div>
            <button type="submit" className="btn btn-primary">Register</button>
            </form>
            <br />
            <br />
            <ul>
              <li>User Name : { this.state.username }</li>
              <li>User City : { this.state.usercity }</li>
              <li>User Age : { this.state.userage }</li>
            </ul>
          </div>
  }
}

export default FormsComponent;