import { Component } from "react";
import { FamilyContext } from "../contexts/family.context";

class ChildComp extends Component{
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px auto"} }>
                    <h1> Child Component</h1>
                    <FamilyContext.Consumer>{(val)=> <h2>{ val || 'place holder' }</h2> }</FamilyContext.Consumer>
               </div>
    }
}

export default ChildComp;
